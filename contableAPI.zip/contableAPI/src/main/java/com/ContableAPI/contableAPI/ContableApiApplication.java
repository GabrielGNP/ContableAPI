package com.ContableAPI.contableAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContableApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContableApiApplication.class, args);
	}

}
