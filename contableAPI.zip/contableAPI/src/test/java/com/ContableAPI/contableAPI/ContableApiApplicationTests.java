package com.ContableAPI.contableAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContableApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
